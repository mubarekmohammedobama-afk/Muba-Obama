# Muba-Obama for Android (v2: AI assistant)

Needs a computer with Android Studio (free).

1. Android Studio > New Project > "Empty Views Activity". Language: Kotlin. Name: Muba-Obama. Package name: com.muba.obama. Minimum SDK: API 29.
2. Copy the files from this zip into your project, replacing the originals:
   - app/src/main/AndroidManifest.xml
   - app/src/main/java/com/muba/obama/MainActivity.kt
   - app/src/main/java/com/muba/obama/PhoneControlService.kt
   - app/src/main/res/xml/accessibility_service_config.xml (create the xml folder if missing)
   - app/src/main/res/values/muba_strings.xml
   - app/src/main/res/drawable/muba_profile.jpg (your profile picture; create the drawable folder if missing)
3. Plug in your phone (USB debugging on) and press Run.
4. On the phone: open Muba-Obama, allow the microphone, then turn on Muba-Obama under Accessibility.
5. A floating orange mic appears. Tap it to turn hands-free on (it turns green), then say "hey Muba" or "hey Obama" plus a command, like "hey Muba open camera". Long-press it for one command without the wake word. Say "stop listening" to turn it off.

Hands-free listens all the time, so it uses more battery, and Android may stop it when the screen is off.

Commands: open <app>, call <number>, tap <text on screen>, type <text>, scroll up/down, go home, go back, recent apps, notifications, screenshot, lock, flashlight on/off, volume up/down, wifi, bluetooth.

Untested code: expect small fixes on your phone.

## v2: AI assistant

Anything that is not a quick built-in command (for example "what's the capital of Kenya" or "open the camera and take a picture") is sent to Claude, which answers out loud and can run phone actions.

- Open the app, tap the gear, paste your Anthropic API key (from console.anthropic.com) and tap Save key. The key is stored only on the phone. Never put it in the code or in this repo.
- You can also type to Muba in the chat box.
- Say "read my screen" and Claude gets the text currently on screen so it can answer. Screen text is only sent when Claude asks for it.
- Each request uses a little API credit.
