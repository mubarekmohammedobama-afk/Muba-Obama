package com.muba.obama

import android.os.Handler
import android.os.Looper

// The conversation shown on the main screen
object Chat {
    val messages = mutableListOf<Pair<Boolean, String>>() // true = you, false = Muba
    var onChange: (() -> Unit)? = null
    private val main = Handler(Looper.getMainLooper())

    fun add(fromUser: Boolean, text: String) {
        main.post {
            messages.add(fromUser to text)
            while (messages.size > 100) messages.removeAt(0)
            onChange?.invoke()
        }
    }
}
