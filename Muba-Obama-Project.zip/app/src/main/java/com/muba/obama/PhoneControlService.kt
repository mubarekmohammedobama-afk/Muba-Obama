package com.muba.obama

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import java.util.Locale

class PhoneControlService : AccessibilityService() {
    companion object { var instance: PhoneControlService? = null }

    private lateinit var tts: TextToSpeech
    private var button: TextView? = null
    private var rec: SpeechRecognizer? = null
    private var handsFree = false
    private var awaitingCommand = false
    private var listening = false
    private var speaking = false
    private val ui = Handler(Looper.getMainLooper())
    private val wake = Regex("\\b(muba|mooba|mubah|ruba|mu ba|moo ba|obama)\\b")

    override fun onServiceConnected() {
        instance = this
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts.language = Locale.getDefault() }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { resume() }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { resume() }
        })
        addButton()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        rec?.destroy()
        button?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }
        tts.shutdown()
        super.onDestroy()
    }

    // Floating mic button, visible over every app
    private fun addButton() {
        val b = TextView(this).apply {
            text = "🎙"; textSize = 24f; gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFFD97757.toInt()) }
            setOnClickListener { toggleHandsFree() }
            setOnLongClickListener { awaitingCommand = true; listen(); true }
        }
        val p = WindowManager.LayoutParams(
            160, 160, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL }
        (getSystemService(WINDOW_SERVICE) as WindowManager).addView(b, p)
        button = b
    }

    private fun say(t: String) {
        speaking = true
        if (tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "muba") != TextToSpeech.SUCCESS) speaking = false
    }

    // Called when Muba finishes talking: pick listening back up
    private fun resume() {
        speaking = false
        ui.post { if ((handsFree || awaitingCommand) && !listening) listen() }
    }

    private fun again() { if (handsFree) ui.postDelayed({ if (handsFree && !listening) listen() }, 400) }

    private fun look() {
        (button?.background as? GradientDrawable)?.setColor(if (handsFree) 0xFF1FAE8A.toInt() else 0xFFD97757.toInt())
    }

    private fun toggleHandsFree() {
        handsFree = !handsFree
        look()
        if (handsFree) { say("Hands-free is on. Say hey Muba."); if (!speaking) listen() }
        else { rec?.destroy(); listening = false; ui.removeCallbacksAndMessages(null); say("Hands-free is off.") }
    }

    private fun listen() {
        if (speaking || listening) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            handsFree = false; look(); say("Open the Muba-Obama app and allow the microphone."); return
        }
        rec?.destroy()
        listening = true
        rec = SpeechRecognizer.createSpeechRecognizer(this).also { r ->
            r.setRecognitionListener(object : RecognitionListener {
                override fun onResults(res: Bundle) {
                    listening = false
                    val text = res.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (text != null) heard(text) else again()
                }
                override fun onError(e: Int) { listening = false; awaitingCommand = false; again() }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM))
        }
    }

    // Wake word logic: "hey Muba open camera", or "hey Muba" then the command
    private fun heard(text: String) {
        if (awaitingCommand) { awaitingCommand = false; handle(text); again(); return }
        val t = text.lowercase(Locale.getDefault())
        val m = wake.find(t)
        if (m == null) { again(); return }
        val rest = t.substring(m.range.last + 1).trim()
        if (rest.isEmpty()) { awaitingCommand = true; say("Yes?") } else { handle(rest); again() }
    }

    // Turns what you said into an action
    private fun handle(raw: String) {
        val t = raw.lowercase(Locale.getDefault()).trim()
        when {
            "stop listening" in t -> { handsFree = false; look(); say("Okay, hands-free is off.") }
            t.startsWith("open ") -> openApp(t.removePrefix("open ").trim())
            t.startsWith("call ") -> call(t.removePrefix("call "))
            t.startsWith("tap ") -> tap(t.removePrefix("tap ").trim())
            t.startsWith("click ") -> tap(t.removePrefix("click ").trim())
            t.startsWith("type ") -> type(raw.trim().substring(5))
            "flashlight" in t || "torch" in t -> torch("off" !in t)
            "volume up" in t -> volume(AudioManager.ADJUST_RAISE)
            "volume down" in t -> volume(AudioManager.ADJUST_LOWER)
            "scroll down" in t -> scroll(true)
            "scroll up" in t -> scroll(false)
            t == "go home" || t == "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            t == "go back" || t == "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "recent" in t -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "notification" in t -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            "screenshot" in t -> performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
            t == "lock" || "lock screen" in t -> performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
            "wifi" in t || "wi-fi" in t -> launch(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
            "bluetooth" in t -> launch(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            else -> say("I don't know that command yet.")
        }
    }

    private fun launch(i: Intent) { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

    private fun openApp(name: String) {
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name) }
        val i = match?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
        if (i == null) say("I can't find $name.") else { say("Opening $name."); launch(i) }
    }

    private fun call(spoken: String) {
        val n = spoken.filter { it.isDigit() || it == '+' }
        if (n.isEmpty()) say("Say the phone number.") else { say("Dialing."); launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$n"))) }
    }

    private fun torch(on: Boolean) {
        val cm = getSystemService(CAMERA_SERVICE) as CameraManager
        try {
            val id = cm.cameraIdList.first { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            cm.setTorchMode(id, on)
        } catch (e: Exception) { say("The flashlight isn't available.") }
    }

    private fun volume(dir: Int) {
        (getSystemService(AUDIO_SERVICE) as AudioManager).adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
    }

    private fun scroll(down: Boolean) {
        val d = resources.displayMetrics
        val x = d.widthPixels / 2f
        val path = Path().apply {
            moveTo(x, d.heightPixels * if (down) 0.7f else 0.3f)
            lineTo(x, d.heightPixels * if (down) 0.3f else 0.7f)
        }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 300)).build(), null, null)
    }

    private fun tap(label: String) {
        var node = rootInActiveWindow?.findAccessibilityNodeInfosByText(label)?.firstOrNull()
        while (node != null && !node.isClickable) node = node.parent
        if (node == null) say("I can't see $label.") else node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun type(text: String) {
        val field = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (field == null) { say("Tap a text box first."); return }
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }
}
