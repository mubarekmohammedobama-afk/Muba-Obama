package com.muba.obama

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

// Talks to Claude. Turns what you say into a spoken answer plus phone actions.
object Brain {
    private const val MODEL = "claude-haiku-4-5-20251001"

    private const val SYSTEM = """You are Muba-Obama, a friendly voice assistant living on the user's Android phone. You can chat, answer questions, and control the phone.

Reply with ONLY one JSON object, no other text and no code fences:
{"say": "what to speak aloud", "actions": [{"do": "action_name", "arg": "argument"}]}

Rules for "say": it is spoken out loud, so keep it to one or two short sentences, plain words, no markdown, no emojis. If you are only doing an action, say a very short confirmation like "Opening the camera."

"actions" may be empty. Actions run in order. Available actions:
open_app (arg: app name, e.g. "camera", "whatsapp", "chrome")
call (arg: phone number digits only; you cannot look up contacts)
tap (arg: exact text of a button or label on screen)
type (arg: text to type into the focused text box)
scroll_down, scroll_up
home, back, recents, notifications, screenshot, lock
flashlight_on, flashlight_off
volume_up, volume_down
wifi, bluetooth (open the settings panel)
web_search (arg: search query, opens the browser)
open_url (arg: full https link)
look (no arg): reads the text currently on the screen and sends it back to you so you can answer. When you use look, leave "say" empty and use no other actions. Use it for things like "what is on my screen" or "read this to me".

If you cannot do something, say so honestly in "say" and use no actions. Never claim to have done something you have no action for."""

    class Reply(val say: String, val actions: List<Pair<String, String>>)

    // (role, content) pairs, most recent conversation turns
    private val history = mutableListOf<Pair<String, String>>()

    @Synchronized
    fun ask(apiKey: String, userText: String): Reply {
        val msgs = JSONArray()
        for ((role, content) in history) {
            msgs.put(JSONObject().put("role", role).put("content", content))
        }
        msgs.put(JSONObject().put("role", "user").put("content", userText))

        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 500)
            .put("system", SYSTEM)
            .put("messages", msgs)

        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        val out: String
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 30000
            c.doOutput = true
            c.setRequestProperty("content-type", "application/json")
            c.setRequestProperty("x-api-key", apiKey)
            c.setRequestProperty("anthropic-version", "2023-06-01")
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                throw Exception(
                    when (code) {
                        401 -> "The API key was rejected."
                        429 -> "Too many requests, try again in a moment."
                        else -> "Server error $code."
                    }
                )
            }
            out = JSONObject(text).getJSONArray("content").getJSONObject(0).getString("text")
        } finally {
            c.disconnect()
        }

        var say = out.trim()
        val acts = mutableListOf<Pair<String, String>>()
        val s = out.indexOf('{')
        val e = out.lastIndexOf('}')
        if (s >= 0 && e > s) {
            try {
                val j = JSONObject(out.substring(s, e + 1))
                say = j.optString("say", "")
                val a = j.optJSONArray("actions")
                if (a != null) {
                    for (i in 0 until a.length()) {
                        val o = a.getJSONObject(i)
                        acts.add(o.optString("do") to o.optString("arg"))
                    }
                }
            } catch (ex: Exception) {
                // If the JSON is broken, just speak the raw text
            }
        }

        history.add("user" to userText)
        history.add("assistant" to out)
        while (history.size > 12) { history.removeAt(0); history.removeAt(0) }

        return Reply(say, acts)
    }
}
