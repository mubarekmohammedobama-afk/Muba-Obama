package com.muba.obama

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val size = (110 * resources.displayMetrics.density).toInt()
        val photo = ImageView(this).apply {
            setImageResource(R.drawable.muba_profile)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setStroke(8, 0xFFD97757.toInt()) }
            clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(size, size).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = 64 }
        }
        val info = TextView(this).apply {
            textSize = 18f
            setPadding(48, 64, 48, 32)
            text = "Muba-Obama\n\n1. Allow the microphone.\n2. Turn on Muba-Obama in Accessibility.\n" +
                "3. Tap the orange mic button that floats on your screen to turn hands-free on (it turns green). Then say \"hey Muba\" (or \"hey Obama\") and a command. Long-press the button to give one command without the wake word.\n\n" +
                "Try: open camera, call 0123456789, tap Send, type hello, scroll down, go home, go back, " +
                "recent apps, notifications, screenshot, lock, flashlight on, volume up, wifi, bluetooth."
        }
        val mic = Button(this).apply {
            text = "1. Allow microphone"
            setOnClickListener { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1) }
        }
        val acc = Button(this).apply {
            text = "2. Turn on phone control"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(photo); addView(info); addView(mic); addView(acc)
        })
    }
}
