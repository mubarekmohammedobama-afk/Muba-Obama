package com.muba.obama

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var chatBox: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var status: TextView
    private lateinit var setup: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val prefs get() = getSharedPreferences("muba", MODE_PRIVATE)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)

        // Header: photo, name, status, settings gear
        val photo = ImageView(this).apply {
            setImageResource(R.drawable.muba_profile)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setStroke(dp(2), 0xFFD97757.toInt()) }
            clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
        }
        val title = TextView(this).apply {
            text = "Muba-Obama"; textSize = 22f; setTextColor(0xFF222222.toInt())
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        status = TextView(this).apply { textSize = 13f; setTextColor(0xFF777777.toInt()) }
        val names = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            addView(title); addView(status)
        }
        val gear = TextView(this).apply {
            text = "⚙"; textSize = 26f; setTextColor(0xFF777777.toInt())
            setPadding(dp(12), dp(4), dp(4), dp(4))
            setOnClickListener { setup.visibility = if (setup.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(photo); addView(names); addView(gear)
        }

        // Setup panel: microphone, phone control, API key
        val mic = Button(this).apply {
            text = "1. Allow microphone"
            setOnClickListener { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1) }
        }
        val acc = Button(this).apply {
            text = "2. Turn on phone control"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val keyBox = EditText(this).apply {
            hint = "3. Paste your Anthropic API key"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine(true)
            textSize = 14f
        }
        val save = Button(this).apply {
            text = "Save key"
            setOnClickListener {
                prefs.edit().putString("api_key", keyBox.text.toString().trim()).apply()
                keyBox.setText("")
                Toast.makeText(this@MainActivity, "Key saved on this phone", Toast.LENGTH_SHORT).show()
                updateStatus()
            }
        }
        val note = TextView(this).apply {
            text = "Get a key at console.anthropic.com. It stays on this phone only."
            textSize = 12f; setTextColor(0xFF777777.toInt())
        }
        setup = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(12), 0, 0)
            addView(mic); addView(acc); addView(keyBox); addView(save); addView(note)
        }

        // Chat area
        chatBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(8)) }
        scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            addView(chatBox)
        }

        // Message box
        val input = EditText(this).apply {
            hint = "Message Muba..."
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            imeOptions = EditorInfo.IME_ACTION_SEND
            setSingleLine(true)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        fun send() {
            val t = input.text.toString().trim()
            if (t.isEmpty()) return
            input.setText("")
            val svc = PhoneControlService.instance
            if (svc == null) {
                Chat.add(true, t)
                Chat.add(false, "Turn on phone control first (gear icon, step 2).")
            } else svc.submit(t, false)
        }
        input.setOnEditorActionListener { _, _, _ -> send(); true }
        val sendBtn = Button(this).apply { text = "Send"; setOnClickListener { send() } }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(input); addView(sendBtn)
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFFAFAFA.toInt())
            setPadding(dp(16), dp(16), dp(16), dp(8))
            addView(header); addView(setup); addView(scroll); addView(bar)
        })
    }

    override fun onResume() {
        super.onResume()
        Chat.onChange = { refresh() }
        refresh()
        updateStatus()
    }

    override fun onPause() {
        Chat.onChange = null
        super.onPause()
    }

    private fun updateStatus() {
        val micOk = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val phoneOk = PhoneControlService.instance != null
        val keyOk = !prefs.getString("api_key", "").isNullOrBlank()
        status.text = when {
            !micOk -> "Needs microphone"
            !phoneOk -> "Phone control is off"
            !keyOk -> "Needs API key"
            else -> "Ready. Say \"hey Muba\" or type below."
        }
        setup.visibility = if (micOk && phoneOk && keyOk) View.GONE else View.VISIBLE
    }

    private fun refresh() {
        chatBox.removeAllViews()
        if (Chat.messages.isEmpty()) {
            chatBox.addView(TextView(this).apply {
                text = "Tap the floating orange mic to turn hands-free on, then say \"hey Muba\" and ask anything: \"open the camera\", \"what's the capital of Kenya\", \"read my screen\"."
                textSize = 15f; setTextColor(0xFF777777.toInt())
                setPadding(dp(4), dp(24), dp(4), 0)
            })
        }
        for ((fromUser, text) in Chat.messages) chatBox.addView(bubble(text, fromUser))
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun bubble(text: String, user: Boolean) = TextView(this).apply {
        this.text = text
        textSize = 16f
        setPadding(dp(14), dp(10), dp(14), dp(10))
        setTextColor(if (user) Color.WHITE else 0xFF222222.toInt())
        background = GradientDrawable().apply {
            cornerRadius = dp(18).toFloat()
            setColor(if (user) 0xFFD97757.toInt() else 0xFFECECEC.toInt())
        }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = if (user) Gravity.END else Gravity.START
            topMargin = dp(6); bottomMargin = dp(6)
            if (user) marginStart = dp(48) else marginEnd = dp(48)
        }
    }
}
